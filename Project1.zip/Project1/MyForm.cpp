#include "MyForm.h"
#include <cmath>
#include <iostream>
using namespace System;
using namespace System::Windows::Forms;
double arr[19][17];
///double Fk[19] = {631000,584700,567000,549100,538000,526600,517000,508000,500000,492200,483900,471800,436600,372600,372600,319900,277300,243500,217000};
double Fk[19];
bool type = false;
double P, q0, Nv, No, Lv;
static void one_column() {
	arr[0][0] = 0.0;
	for (int i = 1; i <= 18; i++) {
		arr[i][0] = arr[i - 1][0] + 5.0;
	}
}
static void two_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][1] = Fk[i];
	}
}
static void three_column() {
	for (int i = 0; i <= 18; i++) {
		if (type == false) {
			arr[i][2] = 1.9 + 0.008 * arr[i][0] + 0.00024 * arr[i][0] * arr[i][0];
		}
		if (type == true) {
			arr[i][2] = 1.9 + 0.01 * arr[i][0] + 0.0003 * arr[i][0] * arr[i][0];
		}
	}
}
static void four_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][3] = arr[i][2] * P * 9.8;
	}
}
static void five_column() {
	for (int i = 0; i <= 18; i++) {
		if (type == false) {
			arr[i][4] = 0.53 + ((3.5 + 0.074 * arr[i][0] + 0.0022 * arr[i][0] * arr[i][0]) / q0);
		}
		if (type == true) {
			arr[i][4] = 0.53 + ((3.6 + 0.08 * arr[i][0] + 0.0028 * arr[i][0] * arr[i][0]) / q0);
		}
	}
}
static void six_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][5] = arr[i][4] * No*q0*Nv*9.8;
	}
}
static void seven_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][6] = arr[i][3] + arr[i][5];
	}
}
static void eight_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][7] = arr[i][1] - arr[i][6];
	}
}
static void nine_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][8] = ((arr[i][1] - arr[i][6]) / (No * q0 * Nv * 9.8+P*9.8));
	}
}
static void ten_column() {
	for (int i = 0; i <= 18; i++) {
		if (type == false) {
			arr[i][9] = 2.4 + 0.009 * arr[i][0] + 0.0003 * arr[i][0] * arr[i][0];
		}
		if (type == true) {
			arr[i][9] = 2.4 + 0.011 * arr[i][0] + 0.0003 * arr[i][0] * arr[i][0];
		}
	}
}
static void eleven_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][10] = arr[i][9] * P * 9.8;
	}
}
static void twelve_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][11] = arr[i][10] + arr[i][5];
	}
}
static void twelveplusone_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][12] = arr[i][11]/((P*9.8) + (No * q0 * Nv * 9.8));
	}
}
static void twelveplustwo_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][13] = (0.27*(arr[i][0]+100))/(5*arr[i][0]+100);
	}
}
static void fifteen_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][14] = arr[i][13]*330;
	}
}
static void sixteen_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][15] = arr[i][14]/2;
	}
}
static void seventeen_column() {
	for (int i = 0; i <= 18; i++) {
		arr[i][16] = arr[i][15] + arr[i][12];
	}
}
void main() {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Project1::MyForm form;
	Application::Run(% form);
}

System::Void Project1::MyForm::MyForm_Load(System::Object^ sender, System::EventArgs^ e)
{
	return System::Void();
}

System::Void Project1::MyForm::button1_Click(System::Object^ sender, System::EventArgs^ e)
{
	Fk[0] = (double)numericUpDown1->Value;
	Fk[1] = (double)numericUpDown2->Value;
	Fk[2] = (double)numericUpDown3->Value;
	Fk[3] = (double)numericUpDown4->Value;
	Fk[4] = (double)numericUpDown5->Value;
	Fk[5] = (double)numericUpDown6->Value;
	Fk[6] = (double)numericUpDown7->Value;
	Fk[7] = (double)numericUpDown8->Value;
	Fk[8] = (double)numericUpDown9->Value;
	Fk[9] = (double)numericUpDown10->Value;
	Fk[10] = (double)numericUpDown11->Value;
	Fk[11] = (double)numericUpDown12->Value;
	Fk[12] = (double)numericUpDown13->Value;
	Fk[13] = (double)numericUpDown14->Value;
	Fk[14] = (double)numericUpDown15->Value;
	Fk[15] = (double)numericUpDown16->Value;
	Fk[16] = (double)numericUpDown17->Value;
	Fk[17] = (double)numericUpDown18->Value;
	Fk[18] = (double)numericUpDown19->Value;
	P = (double)numericUpDown20->Value;
	q0 = (double)numericUpDown21->Value;
	Nv = (double)numericUpDown22->Value;
	No = (double)numericUpDown23->Value;
	Lv = (double)numericUpDown24->Value;
	//P, q0, Nv, No, Lv;
	one_column();
	two_column();
	three_column();
	four_column();
	five_column();
	six_column();
	seven_column();
	eight_column();
	nine_column();
	ten_column();
	eleven_column();
	twelve_column();
	twelveplusone_column();
	twelveplustwo_column();
	fifteen_column();
	sixteen_column();
	seventeen_column();
	for (int i = 0; i <= 17; i++)
	{
		dataGridView1->Rows->Add();
	}
	for (int i = 0; i <= 16; i++)
	{
		for (int j = 0; j <= 18; j++)
		{
			dataGridView1->Rows[j]->Cells[i]->Value = arr[j][i].ToString();
		}
	}
	this->chart1->Series[0]->Points->Clear();
	this->chart1->Series[1]->Points->Clear();
	this->chart1->Series[2]->Points->Clear();
	for (int i = 0; i <= 18; i++) {
		this->chart1->Series[0]->Points->AddXY(arr[i][8] * (-1), arr[i][0]);
		this->chart1->Series[1]->Points->AddXY(arr[i][12], arr[i][0]);
		this->chart1->Series[2]->Points->AddXY(arr[i][16], arr[i][0]);
		this->chart1->Series[3]->Points->AddXY(0, arr[i][0]);
	}
	this->chart1->Series[3]->Points->AddXY(0, arr[18][0]+20);
	
	return System::Void();
}

System::Void Project1::MyForm::printDocument1_PrintPage(System::Object^ sender, System::Drawing::Printing::PrintPageEventArgs^ e)
{
	return System::Void();
}

System::Void Project1::MyForm::button2_Click(System::Object^ sender, System::EventArgs^ e)
{
	chart1->Printing->PageSetup();
	chart1->Printing->PrintPreview();
	this->dataGridView1->Location = System::Drawing::Point(0, 0);
	this->dataGridView1->Size = System::Drawing::Size(1920, 1080);
	this->label2->Visible = false;
	this->button4->Visible = false;
	return System::Void();
}

System::Void Project1::MyForm::button4_Click(System::Object^ sender, System::EventArgs^ e)
{
	if (type == false) {
		type = true;
		this->label2->Text = "���������";
	}
	else{
		type = false;
		this->label2->Text = "�����������";
	}
	return System::Void();
}
